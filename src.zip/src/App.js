import "./App.css";
import { Routes, Route } from "react-router-dom";
import MealsPage from "./components/Layout/MealsPage";
import WelcomePage from "./components/Layout/WelcomePage";
import LoginPage from "./components/Layout/LoginPage";
import Home from "./components/Layout/Home";
function App() {
  return (
    <>
      <Routes>
        <Route exact path="/" element={<WelcomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/login/home" element={<Home />} />
        <Route path="/login/home/mealsPage" element={<MealsPage />} />
      </Routes>
    </>
  );
}

export default App;
